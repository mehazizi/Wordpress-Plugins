<?php
/**
 * Plugin Name:  غیرفعال‌سازی منابع خارجی (Google Fonts و Gravatar)
 * Plugin URI:   https://residentology.ir
 * Description:  حذف فونت‌های گوگل و غیرفعال کردن Gravatar برای سازگاری با شبکه ملی.
 * Version:      1.0
 * Author:       Residentology
 * Author URI:   https://residentology.ir
 */

// جلوگیری از اجرای مستقیم فایل
if (!defined('ABSPATH')) {
    exit;
}

class Disable_External_Assets {

    public function __construct() {
        // ۱. حذف همهٔ درخواست‌های Google Fonts
        add_filter('style_loader_src', array($this, 'remove_google_fonts'), 9999);
        add_action('wp_enqueue_scripts', array($this, 'remove_google_fonts_registered'), 9999);
        add_action('admin_enqueue_scripts', array($this, 'remove_google_fonts_registered'), 9999);

        // ۲. بارگذاری فونت وزیرمتن لوکال از wp-includes/fonts
        add_action('wp_enqueue_scripts', array($this, 'load_vazir_font'));
        add_action('admin_enqueue_scripts', array($this, 'load_vazir_font'));

        // ۳. غیرفعال‌سازی Gravatar و جایگذاری آواتار لوکال
        add_filter('get_avatar', array($this, 'replace_avatar'), 10, 5);
        add_filter('pre_get_avatar', '__return_true'); // از درخواست‌های داخلی جلوگیری می‌کند
    }

    /**
     * حذف هر URLای که مربوط به Google Fonts باشد.
     */
    public function remove_google_fonts($src) {
        if (strpos($src, 'fonts.googleapis.com') !== false) {
            return false;
        }
        return $src;
    }

    /**
     * حذف complete stylesheetهای ثبت‌شده‌ای که ممکن است از طریق wp_enqueue_style اضافه شده باشند.
     */
    public function remove_google_fonts_registered() {
        global $wp_styles;
        if (!empty($wp_styles->registered)) {
            foreach ($wp_styles->registered as $handle => $style) {
                if (strpos($style->src, 'fonts.googleapis.com') !== false) {
                    wp_dequeue_style($handle);
                    wp_deregister_style($handle);
                }
            }
        }
    }

    /**
     * بارگذاری فایل font-face.css فونت وزیرمتن از مسیر wp-includes/fonts/
     */
    public function load_vazir_font() {
        wp_enqueue_style(
            'vazir-font',
            includes_url('fonts/font-face.css'),
            array(),
            '1.0.0'
        );
        // افزودن یک استایل ساده برای تنظیم فونت پیش‌فرض (اختیاری اما مفید)
        wp_add_inline_style('vazir-font', 'body { font-family: Vazir, Tahoma, sans-serif; }');
    }

    /**
     * جایگزینی آواتار Gravatar با یک تصویر لوکال.
     */
    public function replace_avatar($avatar, $id_or_email, $size, $default, $alt) {
        // مسیر تصویر پیش‌فرض (در پوشهٔ همین افزونه)
        $local_avatar = plugin_dir_url(__FILE__) . 'default-avatar.png';
        return '<img src="' . esc_url($local_avatar) . '" width="' . esc_attr($size) . '" height="' . esc_attr($size) . '" alt="' . esc_attr($alt) . '" class="avatar avatar-' . esc_attr($size) . ' photo" loading="lazy" />';
    }

}

new Disable_External_Assets();