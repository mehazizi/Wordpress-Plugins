<?php
/*
Plugin Name: Disable Google Fonts
Description: Removes Google Fonts from WordPress themes and plugins.
Version: 1.0
Author: Your Name
*/

function disable_google_fonts_remove() {
    global $wp_styles;

    if (!isset($wp_styles->registered) || empty($wp_styles->registered)) {
        return;
    }

    foreach ($wp_styles->registered as $handle => $style) {
        if (strpos($style->src, 'fonts.googleapis.com') !== false ||
            strpos($style->src, 'fonts.gstatic.com') !== false) {
            wp_dequeue_style($handle);
            wp_deregister_style($handle);
        }
    }
}

add_action('wp_enqueue_scripts', 'disable_google_fonts_remove', 100);
add_action('admin_enqueue_scripts', 'disable_google_fonts_remove', 100);
