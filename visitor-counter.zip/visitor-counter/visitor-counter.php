<?php
/*
Plugin Name: Visitor Counter
Description: نمایش تعداد بازدیدکنندگان سایت.
Version: 4.1.3.0
Author: ابراهیم عزیزی  09127701030
*/

// جلوگیری از دسترسی مستقیم
if (!defined('ABSPATH')) {
    exit;
}

// تنظیم جدول در پایگاه داده هنگام فعال‌سازی افزونه
function vc_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'visitor_counter';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        visit_time DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'vc_create_table');

// ثبت بازدید در جدول
function vc_track_visit() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'visitor_counter';
    $wpdb->insert($table_name, ['visit_time' => current_time('mysql')]);
}
add_action('wp_head', 'vc_track_visit');

// نمایش تعداد بازدیدها
function vc_display_count() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'visitor_counter';
    $visit_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    return "<p>تعداد بازدیدکنندگان: $visit_count</p>";
}

// ایجاد شورت‌کد برای نمایش
function vc_shortcode() {
    return vc_display_count();
}
add_shortcode('visitor_count', 'vc_shortcode');